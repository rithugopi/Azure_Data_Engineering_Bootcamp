Project 2 - Modified Raw Input Files
These files were intentionally made slightly messy so you can perform cleaning and validation tasks in Databricks.

customer_raw.csv
 - leading/trailing spaces and lowercase names
 - mixed city/country casing and abbreviations
 - invalid and missing emails
 - phone number formatting inconsistencies
 - mixed/invalid/future CreatedDate values
 - one duplicate CustomerID row
 - one missing City value

category_raw.csv
 - leading/trailing spaces
 - missing description
 - duplicate CategoryID
 - category name typo

product_raw.csv
 - whitespace and uppercase ProductName values
 - invalid CategoryID reference
 - negative and missing Price values
 - mixed/invalid/future CreatedDate values
 - one duplicate ProductID row

orders_raw.csv
 - status casing/spacing inconsistencies
 - unexpected status value
 - invalid CustomerID reference
 - negative and missing TotalAmount values
 - mixed/invalid/future OrderDate values
 - one duplicate OrderID row

sales_raw.csv
 - zero and negative Quantity values
 - negative and missing UnitPrice values
 - invalid OrderID and ProductID references
 - mixed/invalid/future SaleDate values
 - one duplicate SaleID row

